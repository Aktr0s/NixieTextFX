var searchData=
[
  ['main_0',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['main_2ecpp_1',['main.cpp',['../main_8cpp.html',1,'']]],
  ['mode_2',['Configures the clock display mode.',['../class_nixie_display.html#autotoc_md22',1,'']]]
];
