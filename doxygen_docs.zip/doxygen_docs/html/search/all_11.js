var searchData=
[
  ['with_20an_20external_20ttf_20font_20file_0',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]],
  ['with_5fseconds_1',['WITH_SECONDS',['../_local_clock_8hpp.html#a3761e219c2f1b047a0bd2c340057c20ea3ae3047395a39d6add6e2c36562ac18b',1,'LocalClock.hpp']]],
  ['without_5fseconds_2',['WITHOUT_SECONDS',['../_local_clock_8hpp.html#a3761e219c2f1b047a0bd2c340057c20ea609ad667b52f5f808e63b097155959ba',1,'LocalClock.hpp']]],
  ['withseconds_3',['withSeconds',['../_local_clock_8hpp.html#a3761e219c2f1b047a0bd2c340057c20e',1,'LocalClock.hpp']]]
];
