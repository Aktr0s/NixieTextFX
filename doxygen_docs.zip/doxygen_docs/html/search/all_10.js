var searchData=
[
  ['usage_3a_0',['usage:',['../class_nixie_display.html#autotoc_md5',1,'Example usage:'],['../class_nixie_display.html#autotoc_md7',1,'Example usage:'],['../class_nixie_display.html#autotoc_md9',1,'Example usage:'],['../class_nixie_display.html#autotoc_md11',1,'Example usage:'],['../class_nixie_display.html#autotoc_md13',1,'Example usage:'],['../class_nixie_display.html#autotoc_md15',1,'Example usage:'],['../class_nixie_display.html#autotoc_md17',1,'Example usage:'],['../class_nixie_display.html#autotoc_md19',1,'Example usage:'],['../class_nixie_display.html#autotoc_md21',1,'Example usage:'],['../class_nixie_display.html#autotoc_md23',1,'Example usage:']]],
  ['using_20embedded_20raw_20byte_20font_20data_1',['Constructor to initialize the Nixie display using embedded raw byte font data.',['../class_nixie_display.html#autotoc_md2',1,'']]]
];
