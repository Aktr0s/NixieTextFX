var _nixie_init_globals_8h =
[
    [ "g_renderer", "_nixie_init_globals_8h.html#a838b791ca11dd8ad488e9fe215a3009b", null ],
    [ "g_window", "_nixie_init_globals_8h.html#acd4cfc6fea5991a14afef7ce65b5c36a", null ]
];