var searchData=
[
  ['data_0',['Constructor to initialize the Nixie display using embedded raw byte font data.',['../class_nixie_display.html#autotoc_md2',1,'']]],
  ['deinitialize_20the_20nixiedisplay_20class_1',['Destructor to deinitialize the NixieDisplay class.',['../class_nixie_display.html#autotoc_md3',1,'']]],
  ['destructor_20to_20deinitialize_20the_20nixiedisplay_20class_2',['Destructor to deinitialize the NixieDisplay class.',['../class_nixie_display.html#autotoc_md3',1,'']]],
  ['display_3',['display',['../class_nixie_display.html#autotoc_md4',1,'Sets the text of the display.'],['../class_nixie_display.html#autotoc_md8',1,'Toggles the flickering effect on the display']]],
  ['display_20based_20on_20the_20specified_20rendering_20type_4',['Renders the display based on the specified rendering type.',['../class_nixie_display.html#autotoc_md6',1,'']]],
  ['display_20mode_5',['Configures the clock display mode.',['../class_nixie_display.html#autotoc_md22',1,'']]],
  ['display_20using_20embedded_20raw_20byte_20font_20data_6',['Constructor to initialize the Nixie display using embedded raw byte font data.',['../class_nixie_display.html#autotoc_md2',1,'']]],
  ['display_20with_20an_20external_20ttf_20font_20file_7',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]],
  ['displayed_20text_8',['displayed text',['../class_nixie_display.html#autotoc_md18',1,'Sets the position of a displayed text'],['../class_nixie_display.html#autotoc_md16',1,'Sets the size of a displayed text']]],
  ['documentation_9',['NixieTextFX Documentation',['../index.html#autotoc_md0',1,'']]]
];
