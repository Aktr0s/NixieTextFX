var searchData=
[
  ['setglowcolor_0',['setGlowColor',['../class_nixie_display.html#af8527616f4d9f61e0da84c84b8ab19df',1,'NixieDisplay']]],
  ['setglowradius_1',['setGlowRadius',['../class_nixie_display.html#a82623d5e9cfa057d046e61402f97a87b',1,'NixieDisplay']]],
  ['setposition_2',['setPosition',['../class_nixie_display.html#a6b4b0359a2313c3784bde698c19065b5',1,'NixieDisplay']]],
  ['sets_20a_20color_20of_20the_20glow_3',['Sets a color of the glow',['../class_nixie_display.html#autotoc_md14',1,'']]],
  ['sets_20a_20color_20of_20the_20text_4',['Sets a color of the text',['../class_nixie_display.html#autotoc_md12',1,'']]],
  ['sets_20a_20radius_20for_20glow_20effect_5',['Sets a radius for glow effect',['../class_nixie_display.html#autotoc_md10',1,'']]],
  ['sets_20the_20position_20of_20a_20displayed_20text_6',['Sets the position of a displayed text',['../class_nixie_display.html#autotoc_md18',1,'']]],
  ['sets_20the_20size_20of_20a_20displayed_20text_7',['Sets the size of a displayed text',['../class_nixie_display.html#autotoc_md16',1,'']]],
  ['sets_20the_20spacing_20between_20characters_8',['Sets the spacing between characters',['../class_nixie_display.html#autotoc_md20',1,'']]],
  ['sets_20the_20text_20of_20the_20display_9',['Sets the text of the display.',['../class_nixie_display.html#autotoc_md4',1,'']]],
  ['setspacing_10',['setSpacing',['../class_nixie_display.html#a62239a026f64891a2028f5764a9b64c7',1,'NixieDisplay']]],
  ['settext_11',['setText',['../class_nixie_display.html#a2b6afca79fd06f120146b6c7b138437c',1,'NixieDisplay']]],
  ['settextcolor_12',['setTextColor',['../class_nixie_display.html#a6c1b9874d4b09253769fe4cd04dfc71a',1,'NixieDisplay']]],
  ['settextsize_13',['setTextSize',['../class_nixie_display.html#aa866bee973325d2c9ad831a212a787de',1,'NixieDisplay']]],
  ['size_20of_20a_20displayed_20text_14',['Sets the size of a displayed text',['../class_nixie_display.html#autotoc_md16',1,'']]],
  ['spacing_20between_20characters_15',['Sets the spacing between characters',['../class_nixie_display.html#autotoc_md20',1,'']]],
  ['specified_20rendering_20type_16',['Renders the display based on the specified rendering type.',['../class_nixie_display.html#autotoc_md6',1,'']]],
  ['style_17',['Style',['../_local_clock_8hpp.html#addb2fa415e015ee482fa2cd9eba96af7',1,'LocalClock.hpp']]]
];
