var searchData=
[
  ['_7enixiedisplay_0',['~NixieDisplay',['../class_nixie_display.html#af1e9133084036ea5bd2de28d246501a0',1,'NixieDisplay']]]
];
