var searchData=
[
  ['clockmode_0',['clockMode',['../class_nixie_display.html#aa250d9f8623a7a8312faab695933d824',1,'NixieDisplay']]]
];
