var searchData=
[
  ['c_5fstyle_0',['C_STYLE',['../_local_clock_8hpp.html#addb2fa415e015ee482fa2cd9eba96af7aa139618b661dcf26da791ae4b178135b',1,'LocalClock.hpp']]],
  ['characters_1',['Sets the spacing between characters',['../class_nixie_display.html#autotoc_md20',1,'']]],
  ['class_2',['Destructor to deinitialize the NixieDisplay class.',['../class_nixie_display.html#autotoc_md3',1,'']]],
  ['clock_20display_20mode_3',['Configures the clock display mode.',['../class_nixie_display.html#autotoc_md22',1,'']]],
  ['clock_5fdisable_4',['CLOCK_DISABLE',['../_nixie_display_8hpp.html#af57b245d27efe0524a39551bcb9fa1c6af2a18499f0a21cc1688fb44ee5fbe02a',1,'NixieDisplay.hpp']]],
  ['clock_5fenable_5',['CLOCK_ENABLE',['../_nixie_display_8hpp.html#af57b245d27efe0524a39551bcb9fa1c6a69641dcbbb3a9d77fc35e83b4aba3781',1,'NixieDisplay.hpp']]],
  ['clockenable_6',['clockEnable',['../_nixie_display_8hpp.html#af57b245d27efe0524a39551bcb9fa1c6',1,'NixieDisplay.hpp']]],
  ['clockmode_7',['clockMode',['../class_nixie_display.html#aa250d9f8623a7a8312faab695933d824',1,'NixieDisplay']]],
  ['color_20of_20the_20glow_8',['Sets a color of the glow',['../class_nixie_display.html#autotoc_md14',1,'']]],
  ['color_20of_20the_20text_9',['Sets a color of the text',['../class_nixie_display.html#autotoc_md12',1,'']]],
  ['configures_20the_20clock_20display_20mode_10',['Configures the clock display mode.',['../class_nixie_display.html#autotoc_md22',1,'']]],
  ['constructor_20to_20initialize_20the_20nixie_20display_20using_20embedded_20raw_20byte_20font_20data_11',['Constructor to initialize the Nixie display using embedded raw byte font data.',['../class_nixie_display.html#autotoc_md2',1,'']]],
  ['constructor_20to_20initialize_20the_20nixie_20display_20with_20an_20external_20ttf_20font_20file_12',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]],
  ['cpp_5fstyle_13',['CPP_STYLE',['../_local_clock_8hpp.html#addb2fa415e015ee482fa2cd9eba96af7ab2ca121258f2fa331a64ec1c138901f0',1,'LocalClock.hpp']]]
];
