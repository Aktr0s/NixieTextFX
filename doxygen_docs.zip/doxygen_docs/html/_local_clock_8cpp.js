var _local_clock_8cpp =
[
    [ "getLocalTime", "_local_clock_8cpp.html#a36f12b64ac76918385cdc343e2687885", null ]
];