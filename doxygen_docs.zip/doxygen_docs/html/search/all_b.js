var searchData=
[
  ['of_20a_20displayed_20text_0',['of a displayed text',['../class_nixie_display.html#autotoc_md18',1,'Sets the position of a displayed text'],['../class_nixie_display.html#autotoc_md16',1,'Sets the size of a displayed text']]],
  ['of_20the_20display_1',['Sets the text of the display.',['../class_nixie_display.html#autotoc_md4',1,'']]],
  ['of_20the_20glow_2',['Sets a color of the glow',['../class_nixie_display.html#autotoc_md14',1,'']]],
  ['of_20the_20text_3',['Sets a color of the text',['../class_nixie_display.html#autotoc_md12',1,'']]],
  ['on_20the_20display_4',['Toggles the flickering effect on the display',['../class_nixie_display.html#autotoc_md8',1,'']]],
  ['on_20the_20specified_20rendering_20type_5',['Renders the display based on the specified rendering type.',['../class_nixie_display.html#autotoc_md6',1,'']]]
];
