var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "LocalClock.cpp", "_local_clock_8cpp.html", "_local_clock_8cpp" ],
    [ "LocalClock.hpp", "_local_clock_8hpp.html", "_local_clock_8hpp" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "NixieDisplay.cpp", "_nixie_display_8cpp.html", null ],
    [ "NixieDisplay.hpp", "_nixie_display_8hpp.html", "_nixie_display_8hpp" ],
    [ "NixieInit.cpp", "_nixie_init_8cpp.html", "_nixie_init_8cpp" ],
    [ "NixieInit.hpp", "_nixie_init_8hpp.html", "_nixie_init_8hpp" ],
    [ "NixieInitGlobals.h", "_nixie_init_globals_8h.html", "_nixie_init_globals_8h" ],
    [ "NixieOne_Mono_ttf.hpp", "_nixie_one___mono__ttf_8hpp.html", "_nixie_one___mono__ttf_8hpp" ]
];