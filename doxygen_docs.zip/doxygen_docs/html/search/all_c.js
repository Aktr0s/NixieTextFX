var searchData=
[
  ['position_20of_20a_20displayed_20text_0',['Sets the position of a displayed text',['../class_nixie_display.html#autotoc_md18',1,'']]]
];
