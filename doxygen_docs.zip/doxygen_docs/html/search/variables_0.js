var searchData=
[
  ['g_5frenderer_0',['g_renderer',['../_nixie_init_8cpp.html#a838b791ca11dd8ad488e9fe215a3009b',1,'g_renderer:&#160;NixieInit.cpp'],['../_nixie_init_8hpp.html#a838b791ca11dd8ad488e9fe215a3009b',1,'g_renderer:&#160;NixieInit.cpp'],['../_nixie_init_globals_8h.html#a838b791ca11dd8ad488e9fe215a3009b',1,'g_renderer:&#160;NixieInit.cpp']]],
  ['g_5fwindow_1',['g_window',['../_nixie_init_8cpp.html#acd4cfc6fea5991a14afef7ce65b5c36a',1,'g_window:&#160;NixieInit.cpp'],['../_nixie_init_8hpp.html#acd4cfc6fea5991a14afef7ce65b5c36a',1,'g_window:&#160;NixieInit.cpp'],['../_nixie_init_globals_8h.html#acd4cfc6fea5991a14afef7ce65b5c36a',1,'g_window:&#160;NixieInit.cpp']]]
];
