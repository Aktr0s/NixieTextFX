var searchData=
[
  ['initialize_20the_20nixie_20display_20using_20embedded_20raw_20byte_20font_20data_0',['Constructor to initialize the Nixie display using embedded raw byte font data.',['../class_nixie_display.html#autotoc_md2',1,'']]],
  ['initialize_20the_20nixie_20display_20with_20an_20external_20ttf_20font_20file_1',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]]
];
