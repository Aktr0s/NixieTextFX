var _local_clock_8hpp =
[
    [ "Style", "_local_clock_8hpp.html#addb2fa415e015ee482fa2cd9eba96af7", [
      [ "CPP_STYLE", "_local_clock_8hpp.html#addb2fa415e015ee482fa2cd9eba96af7ab2ca121258f2fa331a64ec1c138901f0", null ],
      [ "C_STYLE", "_local_clock_8hpp.html#addb2fa415e015ee482fa2cd9eba96af7aa139618b661dcf26da791ae4b178135b", null ]
    ] ],
    [ "withSeconds", "_local_clock_8hpp.html#a3761e219c2f1b047a0bd2c340057c20e", [
      [ "WITH_SECONDS", "_local_clock_8hpp.html#a3761e219c2f1b047a0bd2c340057c20ea3ae3047395a39d6add6e2c36562ac18b", null ],
      [ "WITHOUT_SECONDS", "_local_clock_8hpp.html#a3761e219c2f1b047a0bd2c340057c20ea609ad667b52f5f808e63b097155959ba", null ]
    ] ],
    [ "getLocalTime", "_local_clock_8hpp.html#a36f12b64ac76918385cdc343e2687885", null ]
];