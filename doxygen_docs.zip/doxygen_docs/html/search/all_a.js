var searchData=
[
  ['nixie_20display_20using_20embedded_20raw_20byte_20font_20data_0',['Constructor to initialize the Nixie display using embedded raw byte font data.',['../class_nixie_display.html#autotoc_md2',1,'']]],
  ['nixie_20display_20with_20an_20external_20ttf_20font_20file_1',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]],
  ['nixiecleanup_2',['NixieCleanup',['../_nixie_init_8cpp.html#a704374d5965ef9a44b1f59606f0963da',1,'NixieCleanup():&#160;NixieInit.cpp'],['../_nixie_init_8hpp.html#a704374d5965ef9a44b1f59606f0963da',1,'NixieCleanup():&#160;NixieInit.cpp']]],
  ['nixiedisplay_3',['NixieDisplay',['../class_nixie_display.html',1,'NixieDisplay'],['../class_nixie_display.html#a117a1ea1196a98a23ad4cdc9ec1709f7',1,'NixieDisplay::NixieDisplay(SDL_Renderer *renderer, const std::string &amp;fontPath, SDL_Color textColor={225, 200, 0, 225}, SDL_Color glowColor={200, 10, 0, 128}, int textSize=120)'],['../class_nixie_display.html#ab9f471ac2ba2cd1867b9aaf86a07a042',1,'NixieDisplay::NixieDisplay(SDL_Renderer *renderer, const unsigned char *fontData, size_t fontDataSize, SDL_Color textColor={225, 200, 0, 255}, SDL_Color glowColor={200, 10, 0, 128}, int textSize=120)']]],
  ['nixiedisplay_20class_4',['Destructor to deinitialize the NixieDisplay class.',['../class_nixie_display.html#autotoc_md3',1,'']]],
  ['nixiedisplay_2ecpp_5',['NixieDisplay.cpp',['../_nixie_display_8cpp.html',1,'']]],
  ['nixiedisplay_2ehpp_6',['NixieDisplay.hpp',['../_nixie_display_8hpp.html',1,'']]],
  ['nixieinicial_7',['NixieInicial',['../_nixie_init_8cpp.html#ae89dade7a1038953a8abd16bff275094',1,'NixieInicial(Sint16 width, Sint16 height):&#160;NixieInit.cpp'],['../_nixie_init_8hpp.html#afda18e2be30a554a392684bd910866ca',1,'NixieInicial(Sint16 width=600, Sint16 height=145):&#160;NixieInit.cpp']]],
  ['nixieinit_2ecpp_8',['NixieInit.cpp',['../_nixie_init_8cpp.html',1,'']]],
  ['nixieinit_2ehpp_9',['NixieInit.hpp',['../_nixie_init_8hpp.html',1,'']]],
  ['nixieinitglobals_2eh_10',['NixieInitGlobals.h',['../_nixie_init_globals_8h.html',1,'']]],
  ['nixieone_5fmono_5fttf_11',['NixieOne_Mono_ttf',['../_nixie_one___mono__ttf_8hpp.html#adc3172080b1c16d155a6ce0f5892b8eb',1,'NixieOne_Mono_ttf.hpp']]],
  ['nixieone_5fmono_5fttf_2ehpp_12',['NixieOne_Mono_ttf.hpp',['../_nixie_one___mono__ttf_8hpp.html',1,'']]],
  ['nixieone_5fmono_5fttf_5flen_13',['NixieOne_Mono_ttf_len',['../_nixie_one___mono__ttf_8hpp.html#a188d387720194277f13e8b7de61a539d',1,'NixieOne_Mono_ttf.hpp']]],
  ['nixietextfx_14',['NixieTextFX',['../index.html',1,'']]],
  ['nixietextfx_20documentation_15',['NixieTextFX Documentation',['../index.html#autotoc_md0',1,'']]]
];
