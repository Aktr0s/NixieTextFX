var searchData=
[
  ['nixiecleanup_0',['NixieCleanup',['../_nixie_init_8cpp.html#a704374d5965ef9a44b1f59606f0963da',1,'NixieCleanup():&#160;NixieInit.cpp'],['../_nixie_init_8hpp.html#a704374d5965ef9a44b1f59606f0963da',1,'NixieCleanup():&#160;NixieInit.cpp']]],
  ['nixiedisplay_1',['NixieDisplay',['../class_nixie_display.html#a117a1ea1196a98a23ad4cdc9ec1709f7',1,'NixieDisplay::NixieDisplay(SDL_Renderer *renderer, const std::string &amp;fontPath, SDL_Color textColor={225, 200, 0, 225}, SDL_Color glowColor={200, 10, 0, 128}, int textSize=120)'],['../class_nixie_display.html#ab9f471ac2ba2cd1867b9aaf86a07a042',1,'NixieDisplay::NixieDisplay(SDL_Renderer *renderer, const unsigned char *fontData, size_t fontDataSize, SDL_Color textColor={225, 200, 0, 255}, SDL_Color glowColor={200, 10, 0, 128}, int textSize=120)']]],
  ['nixieinicial_2',['NixieInicial',['../_nixie_init_8cpp.html#ae89dade7a1038953a8abd16bff275094',1,'NixieInicial(Sint16 width, Sint16 height):&#160;NixieInit.cpp'],['../_nixie_init_8hpp.html#afda18e2be30a554a392684bd910866ca',1,'NixieInicial(Sint16 width=600, Sint16 height=145):&#160;NixieInit.cpp']]]
];
