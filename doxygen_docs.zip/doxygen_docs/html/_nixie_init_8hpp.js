var _nixie_init_8hpp =
[
    [ "NixieCleanup", "_nixie_init_8hpp.html#a704374d5965ef9a44b1f59606f0963da", null ],
    [ "NixieInicial", "_nixie_init_8hpp.html#afda18e2be30a554a392684bd910866ca", null ],
    [ "g_renderer", "_nixie_init_8hpp.html#a838b791ca11dd8ad488e9fe215a3009b", null ],
    [ "g_window", "_nixie_init_8hpp.html#acd4cfc6fea5991a14afef7ce65b5c36a", null ]
];