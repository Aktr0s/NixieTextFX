var searchData=
[
  ['effect_0',['Sets a radius for glow effect',['../class_nixie_display.html#autotoc_md10',1,'']]],
  ['effect_20on_20the_20display_1',['Toggles the flickering effect on the display',['../class_nixie_display.html#autotoc_md8',1,'']]],
  ['embedded_20raw_20byte_20font_20data_2',['Constructor to initialize the Nixie display using embedded raw byte font data.',['../class_nixie_display.html#autotoc_md2',1,'']]],
  ['example_20usage_3a_3',['Example usage:',['../class_nixie_display.html#autotoc_md5',1,'Example usage:'],['../class_nixie_display.html#autotoc_md7',1,'Example usage:'],['../class_nixie_display.html#autotoc_md9',1,'Example usage:'],['../class_nixie_display.html#autotoc_md11',1,'Example usage:'],['../class_nixie_display.html#autotoc_md13',1,'Example usage:'],['../class_nixie_display.html#autotoc_md15',1,'Example usage:'],['../class_nixie_display.html#autotoc_md17',1,'Example usage:'],['../class_nixie_display.html#autotoc_md19',1,'Example usage:'],['../class_nixie_display.html#autotoc_md21',1,'Example usage:'],['../class_nixie_display.html#autotoc_md23',1,'Example usage:']]],
  ['external_20ttf_20font_20file_4',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]]
];
