var searchData=
[
  ['style_0',['Style',['../_local_clock_8hpp.html#addb2fa415e015ee482fa2cd9eba96af7',1,'LocalClock.hpp']]]
];
