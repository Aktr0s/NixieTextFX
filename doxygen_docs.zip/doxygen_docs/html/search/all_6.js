var searchData=
[
  ['g_5frenderer_0',['g_renderer',['../_nixie_init_8cpp.html#a838b791ca11dd8ad488e9fe215a3009b',1,'g_renderer:&#160;NixieInit.cpp'],['../_nixie_init_8hpp.html#a838b791ca11dd8ad488e9fe215a3009b',1,'g_renderer:&#160;NixieInit.cpp'],['../_nixie_init_globals_8h.html#a838b791ca11dd8ad488e9fe215a3009b',1,'g_renderer:&#160;NixieInit.cpp']]],
  ['g_5fwindow_1',['g_window',['../_nixie_init_8cpp.html#acd4cfc6fea5991a14afef7ce65b5c36a',1,'g_window:&#160;NixieInit.cpp'],['../_nixie_init_8hpp.html#acd4cfc6fea5991a14afef7ce65b5c36a',1,'g_window:&#160;NixieInit.cpp'],['../_nixie_init_globals_8h.html#acd4cfc6fea5991a14afef7ce65b5c36a',1,'g_window:&#160;NixieInit.cpp']]],
  ['getlocaltime_2',['getLocalTime',['../_local_clock_8cpp.html#a36f12b64ac76918385cdc343e2687885',1,'getLocalTime(Style style, bool dotBlink, withSeconds withSeconds):&#160;LocalClock.cpp'],['../_local_clock_8hpp.html#a36f12b64ac76918385cdc343e2687885',1,'getLocalTime(Style style, bool dotBlink, withSeconds withSeconds):&#160;LocalClock.cpp']]],
  ['glow_3',['Sets a color of the glow',['../class_nixie_display.html#autotoc_md14',1,'']]],
  ['glow_20effect_4',['Sets a radius for glow effect',['../class_nixie_display.html#autotoc_md10',1,'']]]
];
