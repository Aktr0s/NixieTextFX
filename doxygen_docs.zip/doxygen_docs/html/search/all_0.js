var searchData=
[
  ['a_20color_20of_20the_20glow_0',['Sets a color of the glow',['../class_nixie_display.html#autotoc_md14',1,'']]],
  ['a_20color_20of_20the_20text_1',['Sets a color of the text',['../class_nixie_display.html#autotoc_md12',1,'']]],
  ['a_20displayed_20text_2',['a displayed text',['../class_nixie_display.html#autotoc_md18',1,'Sets the position of a displayed text'],['../class_nixie_display.html#autotoc_md16',1,'Sets the size of a displayed text']]],
  ['a_20radius_20for_20glow_20effect_3',['Sets a radius for glow effect',['../class_nixie_display.html#autotoc_md10',1,'']]],
  ['an_20external_20ttf_20font_20file_4',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]]
];
