var searchData=
[
  ['file_0',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]],
  ['flickering_20effect_20on_20the_20display_1',['Toggles the flickering effect on the display',['../class_nixie_display.html#autotoc_md8',1,'']]],
  ['font_20data_2',['Constructor to initialize the Nixie display using embedded raw byte font data.',['../class_nixie_display.html#autotoc_md2',1,'']]],
  ['font_20file_3',['Constructor to initialize the Nixie display with an external .ttf font file.',['../class_nixie_display.html#autotoc_md1',1,'']]],
  ['for_20glow_20effect_4',['Sets a radius for glow effect',['../class_nixie_display.html#autotoc_md10',1,'']]]
];
