var _nixie_init_8cpp =
[
    [ "NixieCleanup", "_nixie_init_8cpp.html#a704374d5965ef9a44b1f59606f0963da", null ],
    [ "NixieInicial", "_nixie_init_8cpp.html#ae89dade7a1038953a8abd16bff275094", null ],
    [ "g_renderer", "_nixie_init_8cpp.html#a838b791ca11dd8ad488e9fe215a3009b", null ],
    [ "g_window", "_nixie_init_8cpp.html#acd4cfc6fea5991a14afef7ce65b5c36a", null ]
];