var searchData=
[
  ['getlocaltime_0',['getLocalTime',['../_local_clock_8cpp.html#a36f12b64ac76918385cdc343e2687885',1,'getLocalTime(Style style, bool dotBlink, withSeconds withSeconds):&#160;LocalClock.cpp'],['../_local_clock_8hpp.html#a36f12b64ac76918385cdc343e2687885',1,'getLocalTime(Style style, bool dotBlink, withSeconds withSeconds):&#160;LocalClock.cpp']]]
];
