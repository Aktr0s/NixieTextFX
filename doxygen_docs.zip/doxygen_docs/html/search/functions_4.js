var searchData=
[
  ['render_0',['render',['../class_nixie_display.html#a722e61b935edb31c089c48c169de19db',1,'NixieDisplay']]]
];
