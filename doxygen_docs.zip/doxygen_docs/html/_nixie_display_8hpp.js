var _nixie_display_8hpp =
[
    [ "NixieDisplay", "class_nixie_display.html", "class_nixie_display" ],
    [ "blinkingDots", "_nixie_display_8hpp.html#a30329bb613837c0c600e64643180f979", [
      [ "BLINKING_DOTS_ON", "_nixie_display_8hpp.html#a30329bb613837c0c600e64643180f979aaa7ff03447dadeac68eb7854611c232c", null ],
      [ "BLINKING_DOTS_OFF", "_nixie_display_8hpp.html#a30329bb613837c0c600e64643180f979a6700dbcc79d2668dae1f427423416be2", null ]
    ] ],
    [ "clockEnable", "_nixie_display_8hpp.html#af57b245d27efe0524a39551bcb9fa1c6", [
      [ "CLOCK_ENABLE", "_nixie_display_8hpp.html#af57b245d27efe0524a39551bcb9fa1c6a69641dcbbb3a9d77fc35e83b4aba3781", null ],
      [ "CLOCK_DISABLE", "_nixie_display_8hpp.html#af57b245d27efe0524a39551bcb9fa1c6af2a18499f0a21cc1688fb44ee5fbe02a", null ]
    ] ],
    [ "renderType", "_nixie_display_8hpp.html#a8ad7d100dd6f63b736e900c57155f327", [
      [ "RENDER_PRESENT", "_nixie_display_8hpp.html#a8ad7d100dd6f63b736e900c57155f327aa9b712cd4e217da3c4770c7ebc294b4e", null ],
      [ "RENDER_PREPARE", "_nixie_display_8hpp.html#a8ad7d100dd6f63b736e900c57155f327ad5dda11f6cdfbf9c0f4aecf2d29bdaf9", null ]
    ] ]
];