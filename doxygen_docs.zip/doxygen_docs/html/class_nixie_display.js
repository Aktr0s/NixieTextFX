var class_nixie_display =
[
    [ "NixieDisplay", "class_nixie_display.html#a117a1ea1196a98a23ad4cdc9ec1709f7", null ],
    [ "NixieDisplay", "class_nixie_display.html#ab9f471ac2ba2cd1867b9aaf86a07a042", null ],
    [ "~NixieDisplay", "class_nixie_display.html#af1e9133084036ea5bd2de28d246501a0", null ],
    [ "clockMode", "class_nixie_display.html#aa250d9f8623a7a8312faab695933d824", null ],
    [ "render", "class_nixie_display.html#a722e61b935edb31c089c48c169de19db", null ],
    [ "setGlowColor", "class_nixie_display.html#af8527616f4d9f61e0da84c84b8ab19df", null ],
    [ "setGlowRadius", "class_nixie_display.html#a82623d5e9cfa057d046e61402f97a87b", null ],
    [ "setPosition", "class_nixie_display.html#a6b4b0359a2313c3784bde698c19065b5", null ],
    [ "setSpacing", "class_nixie_display.html#a62239a026f64891a2028f5764a9b64c7", null ],
    [ "setText", "class_nixie_display.html#a2b6afca79fd06f120146b6c7b138437c", null ],
    [ "setTextColor", "class_nixie_display.html#a6c1b9874d4b09253769fe4cd04dfc71a", null ],
    [ "setTextSize", "class_nixie_display.html#aa866bee973325d2c9ad831a212a787de", null ],
    [ "toggleFlickering", "class_nixie_display.html#aae8287be0a643c354f826ee49bd0bca4", null ]
];