var searchData=
[
  ['setglowcolor_0',['setGlowColor',['../class_nixie_display.html#af8527616f4d9f61e0da84c84b8ab19df',1,'NixieDisplay']]],
  ['setglowradius_1',['setGlowRadius',['../class_nixie_display.html#a82623d5e9cfa057d046e61402f97a87b',1,'NixieDisplay']]],
  ['setposition_2',['setPosition',['../class_nixie_display.html#a6b4b0359a2313c3784bde698c19065b5',1,'NixieDisplay']]],
  ['setspacing_3',['setSpacing',['../class_nixie_display.html#a62239a026f64891a2028f5764a9b64c7',1,'NixieDisplay']]],
  ['settext_4',['setText',['../class_nixie_display.html#a2b6afca79fd06f120146b6c7b138437c',1,'NixieDisplay']]],
  ['settextcolor_5',['setTextColor',['../class_nixie_display.html#a6c1b9874d4b09253769fe4cd04dfc71a',1,'NixieDisplay']]],
  ['settextsize_6',['setTextSize',['../class_nixie_display.html#aa866bee973325d2c9ad831a212a787de',1,'NixieDisplay']]]
];
